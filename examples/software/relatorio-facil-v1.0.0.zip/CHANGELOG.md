# Histórico

## 1.0.0

- Leitura e validação de CSV de vendas.
- Cálculo com Decimal, sem arredondamento por ponto flutuante.
- Relatório HTML responsivo, sem recursos externos.
- Dados fictícios e exemplo de relatório incluídos.
