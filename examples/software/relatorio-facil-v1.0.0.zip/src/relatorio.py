"""Gera um relatório local de vendas a partir de CSV. Python 3.11+."""
import argparse
import csv
from datetime import date
from decimal import Decimal, InvalidOperation
from html import escape
from pathlib import Path
import sys


def gerar(entrada, saida):
    registros = []
    with entrada.open(encoding='utf-8-sig', newline='') as arquivo:
        leitor = csv.DictReader(arquivo)
        campos = {'data', 'produto', 'quantidade', 'valor_unitario'}
        if not campos.issubset(leitor.fieldnames or []):
            raise ValueError('O CSV deve conter: data,produto,quantidade,valor_unitario')
        for numero, linha in enumerate(leitor, 2):
            try:
                data = date.fromisoformat(linha['data'])
                produto = linha['produto'].strip()
                quantidade = int(linha['quantidade'])
                valor = Decimal(linha['valor_unitario'])
                if not produto or quantidade <= 0 or not valor.is_finite() or valor < 0 or valor.as_tuple().exponent < -2:
                    raise ValueError()
            except (ValueError, TypeError, AttributeError, InvalidOperation):
                raise ValueError(f'Linha {numero}: dados inválidos. Use data AAAA-MM-DD, quantidade positiva e valor com ponto e até duas casas decimais.') from None
            registros.append((data, produto, quantidade, valor))
    if not registros:
        raise ValueError('O CSV não contém vendas.')
    total = sum((q * v for _, _, q, v in registros), Decimal('0'))
    unidades = sum(q for _, _, q, _ in registros)
    moeda = lambda valor: f'R$ {valor:,.2f}'.replace(',', '_').replace('.', ',').replace('_', '.')
    linhas = ''.join(f'<tr><td>{d:%d/%m/%Y}</td><td>{escape(p)}</td><td>{q}</td><td>{moeda(v)}</td><td>{moeda(q*v)}</td></tr>' for d,p,q,v in registros)
    documento = '''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Relatório de vendas</title><style>body{font:16px system-ui,sans-serif;color:#173c2c;background:#f4f7f5;margin:0;padding:32px}main{max-width:960px;margin:auto}h1{letter-spacing:-1px}section{display:flex;gap:16px;flex-wrap:wrap;margin:24px 0}article{background:white;border:1px solid #dae4de;border-radius:12px;padding:20px;flex:1}strong{display:block;font-size:28px;margin-top:8px}.tabela{overflow:auto}table{width:100%;border-collapse:collapse;background:white}th,td{text-align:left;padding:14px;border-bottom:1px solid #dae4de}small{color:#596c60}@media print{body{background:white;padding:0}}</style><main><small>RELATÓRIO LOCAL · SOFTWARE DE DEMONSTRAÇÃO</small><h1>Suas vendas, com clareza.</h1>'''
    documento += f'<section><article>Faturamento<strong>{moeda(total)}</strong></article><article>Unidades<strong>{unidades}</strong></article><article>Registros<strong>{len(registros)}</strong></article></section>'
    documento += '<div class="tabela"><table><thead><tr><th>Data</th><th>Produto</th><th>Quantidade</th><th>Preço unitário</th><th>Total</th></tr></thead><tbody>'+linhas+'</tbody></table></div><p><small>Valores informados no CSV. Este relatório não verifica pagamentos nem substitui documentação fiscal.</small></p></main></html>'
    with saida.open('x', encoding='utf-8') as arquivo:
        arquivo.write(documento)
    return total


def main():
    parser = argparse.ArgumentParser(description='Transforme seu CSV de vendas em um relatório HTML local.')
    parser.add_argument('csv', type=Path, help='Arquivo CSV de entrada')
    parser.add_argument('--saida', type=Path, default=Path('relatorio.html'), help='Novo arquivo HTML; não sobrescreve arquivos existentes')
    args = parser.parse_args()
    try:
        total = gerar(args.csv, args.saida)
    except (OSError, ValueError, csv.Error, UnicodeError) as erro:
        print(f'Erro: {erro}', file=sys.stderr)
        return 1
    print(f'Relatório criado: {args.saida} | Faturamento: BRL {total:.2f}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
