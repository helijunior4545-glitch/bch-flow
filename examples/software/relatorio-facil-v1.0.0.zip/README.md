# Relatório Fácil — versão 1.0.0

Software funcional de demonstração para testar a venda e a entrega de arquivos no BCH Flow.
Lê um CSV de vendas e gera um relatório HTML com faturamento, unidades e detalhamento.
Funciona localmente: não envia informações para a internet, não processa pagamentos e não pede credenciais.

## Requisitos

- Python 3.11 ou superior.
- Windows, macOS ou Linux com Python instalado.
- Nenhuma biblioteca externa, API, chave ou assinatura paga.

## Comece aqui

1. Extraia o ZIP.
2. Abra um terminal dentro da pasta extraída.
3. Execute:

```sh
python src/relatorio.py examples/vendas.csv --saida meu-relatorio.html
```

No Linux/macOS, se necessário, use `python3` no lugar de `python`.
No Windows, também é possível usar `py -3`.

Abra `meu-relatorio.html` no navegador. O faturamento do exemplo deve ser R$ 283,80,
com 6 unidades e 3 registros. Você também pode abrir `examples/relatorio-exemplo.html`
para ver o resultado sem executar Python.

O programa não sobrescreve arquivos existentes. Para rodar novamente, escolha outro
nome em `--saida` ou remova o relatório anterior que você gerou.

## Seus próprios dados

Use um CSV UTF-8 separado por vírgulas, com estas colunas:

```csv
data,produto,quantidade,valor_unitario
2026-11-01,Meu produto,1,29.90
```

Datas: AAAA-MM-DD. Quantidade: inteiro positivo. Preço: BRL, não negativo,
com ponto decimal e no máximo duas casas. Valores com vírgulas no nome do
produto precisam estar entre aspas, conforme o formato CSV.

Erros de entrada são reportados sem gerar um relatório parcial. O HTML escapa
os nomes dos produtos. O relatório não considera impostos, taxas ou estornos;
é um resumo dos valores que você forneceu, não uma confirmação financeira.

## Conteúdo

- `src/relatorio.py`: código-fonte completo.
- `examples/vendas.csv`: dados fictícios.
- `examples/relatorio-exemplo.html`: resultado pronto para visualizar.
- `LICENSE.txt`: licença MIT.
- `CHANGELOG.md`: histórico da versão.

## Para cadastrar no BCH Flow

- Nome: Relatório Fácil — Gerador de relatórios CSV.
- Versão: 1.0.0.
- Requisitos: Python 3.11+, Windows/macOS/Linux. Sem dependências externas.
- Licença: MIT; uso, modificação e redistribuição permitidos conforme LICENSE.txt.
- Suporte: pacote demonstrativo, sem suporte contratado ou atualizações garantidas.
- Arquivo: envie o ZIP inteiro, sem extrair no formulário de publicação.

Escolha os preços e contas de recebimento no formulário. Este arquivo não habilita
provedores nem confirma pagamentos. Em uma cobrança real, use apenas um valor
que você aceita pagar; o envio do pacote não cria um estorno automático.
